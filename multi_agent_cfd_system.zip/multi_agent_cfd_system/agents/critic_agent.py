class CriticAgent:

    def reflect(self, result, params):

        print("[Critic] analyzing trajectory")

        updated = params.copy()

        if result["status"] == "failed":

            updated["mesh_density"] = "fine"
            updated["fuel_air_ratio"] *= 0.9

        return updated
