import random


class PlannerAgent:

    def plan(self, goal):

        print("[Planner] generating optimization trajectory")

        return {
            "swirler_angle": random.uniform(35, 60),
            "fuel_air_ratio": random.uniform(0.02, 0.08),
            "hole_diameter": random.uniform(2, 8),
            "mesh_density": random.choice(["coarse", "medium", "fine"])
        }
