class OptimizationAgent:

    def optimize(self, current_params, memory):

        best = memory.get_best()

        if not best:
            return current_params

        improved = current_params.copy()

        improved["swirler_angle"] *= 1.02
        improved["hole_diameter"] *= 0.98

        return improved
