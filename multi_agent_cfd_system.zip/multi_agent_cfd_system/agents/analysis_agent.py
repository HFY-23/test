class AnalysisAgent:

    def evaluate(self, result):

        if result["status"] != "success":

            return {
                "score": 0,
                "status": "failed"
            }

        score = (
            (30 - result["nox"]) * 0.4 +
            (6 - result["pressure_drop"]) * 0.3 +
            result["temp_uniformity"] * 10 * 0.3
        )

        return {
            "score": score,
            "status": "success"
        }
