from tools.mesh_tool import generate_mesh
from tools.fluent_runner import run_fluent
from tools.hpc_scheduler import submit_job


class SimulationAgent:

    def run_case(self, params):

        print(f"[Simulation] params = {params}")

        mesh_file = generate_mesh(params)

        job_id = submit_job(mesh_file)

        result = run_fluent(mesh_file, params)

        result["job_id"] = job_id

        return result
