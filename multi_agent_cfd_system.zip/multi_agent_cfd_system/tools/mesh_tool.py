import uuid


def generate_mesh(params):

    mesh_name = f"mesh_{uuid.uuid4().hex}.msh"

    print(f"[MeshTool] generated {mesh_name}")

    return mesh_name
