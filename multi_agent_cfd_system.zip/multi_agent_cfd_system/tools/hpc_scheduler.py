import uuid


def submit_job(case_name):

    job_id = uuid.uuid4().hex[:8]

    print(f"[HPC] submitted job {job_id}")

    return job_id
