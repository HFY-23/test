def parse_result(raw_result):

    return {
        "parsed": True,
        "data": raw_result
    }
