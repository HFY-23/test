import random
import time


def run_fluent(mesh_file, params):

    print(f"[Fluent] solving CFD case: {mesh_file}")

    time.sleep(1)

    converged = random.random() > 0.2

    if not converged:

        return {
            "status": "failed",
            "reason": "divergence"
        }

    return {
        "status": "success",
        "nox": random.uniform(10, 30),
        "pressure_drop": random.uniform(2, 6),
        "temp_uniformity": random.uniform(0.7, 0.99)
    }
