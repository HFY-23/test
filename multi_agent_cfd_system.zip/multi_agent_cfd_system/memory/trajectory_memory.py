class TrajectoryMemory:

    def __init__(self):

        self.history = []

    def add(self, record):

        self.history.append(record)

    def get_best(self):

        if not self.history:
            return None

        return sorted(
            self.history,
            key=lambda x: x["score"],
            reverse=True
        )[0]

    def recent_failures(self):

        return [
            h for h in self.history
            if h["status"] == "failed"
        ]
